<?php
	include 'partes/cabecera.php';
?>



<?php
	include 'partes/pie.php';
?>