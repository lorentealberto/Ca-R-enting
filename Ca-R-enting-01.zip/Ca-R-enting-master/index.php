<?php
	include 'partes/cabecera.php';
	include 'servicios/ServicioVehiculo.php';
?>

<div class="mt-5 cuerpo">
	<h3 class="text-info">
		Algunos vehículos de nuestro <a href="catalogo.php"><u>catálogo</u></a>:
		<?php mostrarVehiculo(1); ?>
	</h3>
</div>

<?php
	include 'partes/pie.php';
?>