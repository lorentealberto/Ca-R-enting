<?php
	/**Objeto que representa un vehículo dentro del sistema. Tiene todos los 
	*	atributos*/ 
	class ObjetoVehiculo {
		
		private $id;
		private $nombre;
		private $tipoVehiculo;
		private $rutaIMG;
		private $precioDia;
		
		function __construct($_id, $_nombre, $_tipoVehiculo, $_precioXDia,
				$_rutaIMG) {
			$this->id = $_id;
			$this->nombre = $_nombre;
			$this->tipoVehiculo = $_tipoVehiculo;
			$this->rutaIMG = $_rutaIMG;
			$this->precioXDia = $_precioXDia;
		}

		//GETTERS & SETTERS
		public function getID() {
			return $this->id;
		}

		public function setID($_id) {
			$this->id = $id;
		}
		
		public function getNombre() {
			return $this->nombre;
		}

		public function setNombre($_nombre) {
			$this->nombre = $_nombre;
		}
		
		public function getCarnetNecesario() {
			return $this->tipoVehiculo;
		}

		public function setCarnetNecesario($_tipoVehiculo) {
			$this->tipoVehiculo = $_tipoVehiculo;
		}
		
		public function getRutaIMG() {
			return $this->rutaIMG;
		}

		public function setRutaIMG($_rutaIMG) {
			$this->rutaIMG = $_rutaIMG;
		}
		
		public function getPrecioXDia() {
			return $this->precioXDia;
		}

		public function setPrecioXDia($_precioXDia) {
			$this->precioXDia = $_precioXDia;
		}
	}
?>