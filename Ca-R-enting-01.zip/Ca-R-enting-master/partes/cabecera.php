<!DOCTYPE html>
<html lang="es">
<head>
	<title>Ca(R)enting</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

	<script type="text/javascript" src="scripts/librerias/jquery-3.4.1.min.js"></script>
</head>
<body class="bg-light">
	<header>
		<div class="container-fluid bg-info">
			<div class="row">
				<div class="col">
					<?php include 'partes/mensajeAdvertenciaNoSesion.php'; ?>
				</div>
				<div class="col">
					<h1 class="text-light text-right">
						<a href="index.php" class="text-white">Ca(R)enting</a>
					</h1>
				</div>
			</div>
		</div>
	</header>
	<section class="container">