<?php 
	session_start();

	if (isset($_SESSION['idUsuario'])) {
?>
	<!-- Mostrar información cuando el usuario ha iniciado sesión. -->
<?php } else { ?>
	<!-- Mostrar información cuando el usuario no ha iniciado sesión. -->
	<p class="text-warning">
		<h6 class="text-warning">
		¡Atención! No ha iniciado sesión. Si no tiene cuenta cree una pulsando <a href="iniciarSesion.php" class="text-warning"><strong>aquí</strong></a>
		</h6>
	</p>
<?php } ?>