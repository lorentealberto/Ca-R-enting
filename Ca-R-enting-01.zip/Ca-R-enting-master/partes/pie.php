		</section>
		<div class="container-fluid">
			<link rel="stylesheet" href="estilos/pie.css">
			<footer class="page-footer font-small">
				Copyright 2019 - Ca(R)enting
			</footer>
		</div>
	</body>
</html>