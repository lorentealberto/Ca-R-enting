<?php
	include 'objetos/VehiculoObjeto.php';

	//Se conecta al servidor de base de datos y se selecciona la base de datos
	$mysqli = new mysqli("localhost", "root", "", "carenting");

	//Se comprueba si hay algún tipo de error en la conexión
	if($mysqli->connect_errno) {
		printf('Falló la conexión: %s\n', $mysqli->connect_error);
		exit();
	}

	/**Carga un vehículo desde la BBDD usando su ID.
	* param $_idVehiculo: ID del vehículo que se desea cargar.
	* return nuevo vehículo con las caractéristicas obtenidas desde la BBDD.*/
	function cargarVehiculo($_idVehiculo) {
		global $mysqli;

		$query_str = sprintf("SELECT * FROM VEHICULO WHERE ID_VEHICULO = '%d' LIMIT 1", $_idVehiculo);
		$query_exe = $mysqli->query($query_str) or die($mysqli->error);

		$vehiculo = $query_exe->fetch_assoc();

		$id_vehiculo = $vehiculo['ID_VEHICULO'];
		$nombre_vehiculo = $vehiculo['NOMBRE_VEHICULO']; 
		$tipo_vehiculo = $vehiculo['TIPO_VEHICULO'];
		$precio_x_dia = $vehiculo['PRECIOXDIA'];
		$img_vehiculo = $vehiculo['RUTA_IMG'];

		return new ObjetoVehiculo($id_vehiculo, $nombre_vehiculo, $tipo_vehiculo, $precio_x_dia, $img_vehiculo);
	}

	/**Función que muestra un vehículo cuya ID sea igual a la por parámetro.
	* param $_idVehiculo: ID del vehículo que queremos mostrar.*/
	function mostrarVehiculo($_idVehiculo) {
		?>
		<div class="col-md-4 mt-5 text-center ">
			<?php $vehiculo = cargarVehiculo($_idVehiculo); ?>
			<a href="vehiculo.php?id_vehiculo=<?php echo $vehiculo->getID(); ?>">
				<img src="imagenes/<?php echo $vehiculo->getRutaIMG(); ?>" alt="<?php echo $vehiculo->getNombre(); ?>" class="img-thumbnail" />
				<h6 class="bg-dark text-light w-75 p-2 mx-auto rounded-bottom">
					<?php echo $vehiculo->getNombre(); ?>
					<u>Desde <?php echo $vehiculo->getPrecioXDia(); ?>€ / Día</u>
				</h6>
			</a>		
		</div>
		<?php
	}
?>